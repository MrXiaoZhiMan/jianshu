window.onload = function () {
    var s = document.getElementsByTagName("td");
    var number = document.getElementById("top_left_bottom");
    var numbers = document.getElementById("top_left_middle");
    var flag = true;
    var flags = true;
    var strs = "";
    var temp = ""
    for (var i = 0; i < s.length; i++) {
        s[i].onclick = function () {
            strs += this.innerHTML;
            var lastString = strs.slice(strs.length - 1, strs.length);
            var lastString_1 = strs.slice(strs.length - 2, strs.length - 1);
            if (this.innerHTML == "0" || this.innerHTML == "1" || this.innerHTML == "2" || this.innerHTML == "3" ||
                this.innerHTML == "4" || this.innerHTML == "5" || this.innerHTML == "6" || this.innerHTML == "7" ||
                this.innerHTML == "8" || this.innerHTML == "9") {
                if (flag) {
                    number.innerHTML += this.innerHTML;
                }
                else {
                    number.innerHTML = "";
                    number.innerHTML += this.innerHTML;
                    flag = true;
                }
            }
            if (flags == true && (this.innerHTML == "+" || this.innerHTML == "-" || this.innerHTML == "×" || this.innerHTML == "÷" || this.innerHTML == "%")) {
                numbers.innerHTML = number.innerHTML + this.innerHTML;
                temp = number.innerHTML;
                fangfa = this.innerHTML;
                flag = false;
                flags = false;
            }
            else if (flags == false && (this.innerHTML == "+" || this.innerHTML == "-" || this.innerHTML == "×" || this.innerHTML == "÷" || this.innerHTML == "%")) {
                var s = numbers.innerHTML.lastIndexOf(fangfa);
                temp = number.innerHTML;
                numbers.innerHTML = numbers.innerHTML.slice(0, s);
                number.innerHTML = suanshu(fangfa);
                var str = number.innerHTML + this.innerHTML;
                numbers.innerHTML = str;
                flag = false;
            }
            if (this.innerHTML == "=") {
                if (lastString == lastString_1) {
                    console.log("运行了1");
                    numbers.innerHTML = numbers.innerHTML.replace(temp, number.innerHTML);
                    var lastString_2 = numbers.innerHTML.slice(0, numbers.innerHTML.length - 1);
                    temp = number.innerHTML;
                    lastString_2 = lastString_2.replace("×", "*");
                    lastString_2 = lastString_2.replace("÷", "/");
                    number.innerHTML = eval(lastString_2);
                } else {
                    console.log("运行了2");
                    var s = numbers.innerHTML.lastIndexOf(fangfa);
                    var str = numbers.innerHTML + number.innerHTML + this.innerHTML;
                    numbers.innerHTML = numbers.innerHTML.slice(0, s);
                    number.innerHTML = suanshu(fangfa);
                    numbers.innerHTML = str;
                    flag = false;
                    flags = true;
                }
            }
            switch (this.innerHTML) {
                case "C":
                    C();
                    break;
                case "CE":
                    C();
                    break;
                case '<img src="img/delete.jpg" alt="">':
                    s = number.innerHTML.length
                    number.innerHTML = number.innerHTML.slice(0, s - 1);
                    break;
                case '<img src="img/sqrt.jpg" alt="">':
                    numbers.innerHTML = "√" + "(" + number.innerHTML + ")";
                    number.innerHTML = Math.sqrt(number.innerHTML);
                    break;
                case '<img src="img/cheng.jpg" alt="">':
                    numbers.innerHTML = "sqr" + "(" + number.innerHTML + ")";
                    number.innerHTML = Math.pow(number.innerHTML, 2);
                    break;
                case '<img src="img/cbrt.jpg" alt="">':
                    numbers.innerHTML = "sqr" + "(" + number.innerHTML + ")";
                    number.innerHTML = Math.pow(number.innerHTML, 3);
                    break;
                case '<img src="img/daoshu.jpg" alt="">':
                    numbers.innerHTML = "1" + "/" + "(" + number.innerHTML + ")";
                    number.innerHTML = 1 / Number(number.innerHTML)
                    break;
                case '<img src="img/zhengfu.jpg" alt="">':
                    if (number.innerHTML.indexOf("-")) {
                        number.innerHTML = "-" + number.innerHTML;
                    }
                    else {
                        number.innerHTML = Math.abs(number.innerHTML)
                    }
                    break;
                case ".":
                    if (number.innerHTML.indexOf(".") == -1) {
                        number.innerHTML += this.innerHTML;
                    }
                    break;
            }
        }
    }
    function suanshu(a) {
        if (fangfa == a) {
            if (a == "×") {
                a = "*";
            }
            if (a == "÷") {
                a = "/";
            }
            number.innerHTML = eval(numbers.innerHTML + a + number.innerHTML);
            return number.innerHTML;
        }
    }
    function C() {
        number.innerHTML = "";
        numbers.innerHTML = "";
        flags = true;
        flag = true;
        temp = "";
        strs = "";
        fangfa = "";
    }
}