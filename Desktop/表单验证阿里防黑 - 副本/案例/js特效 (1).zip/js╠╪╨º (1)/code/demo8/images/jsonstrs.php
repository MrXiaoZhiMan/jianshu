<?php
header("content-type:text/html;charset=utf-8");
sleep(3);
echo '[{"study":"好好学习，天天向上","imgpath":"a.jpg"},{"study":"勤能补拙","imgpath":"b.jpg"},{"study":"温故而知新","imgpath":"c.jpg"}]';
?>